import { Component } from '@angular/core';

@Component({
  selector: 'app-create-guild',
  standalone: true,
  imports: [],
  template: `
    <p>
      create-guild works!
    </p>
  `,
  styles: ``
})
export class CreateGuildComponent {

}
